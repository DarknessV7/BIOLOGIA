angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {
$scope.juegos =[{
    nombre : "Importancia del Agua: ",
    img : "https://encolombia.com/wp-content/uploads/2019/03/importancia-agua-medio-ambiente.jpg"
  },{
    nombre : "ADN prototipo y ¿Qué es?: ",
    img : "https://okdiario.com/img/2017/09/13/adn-655x368.jpg"
  },{
    nombre : "Tabla Nutricional: ",
    img : "https://sites.google.com/site/educanutant/_/rsrc/1417869657375/mitos-sobre-la-alimentacion/1.jpg"
  }]


})

.controller('ChatsCtrl', function($scope, Chats) {
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
})

.controller('AccountCtrl', function($scope) {
})


.controller('infoCtrl',function($scope){
  //controlador 
});
